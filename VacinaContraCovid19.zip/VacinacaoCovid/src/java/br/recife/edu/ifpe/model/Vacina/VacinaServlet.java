/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.recife.edu.ifpe.model.Vacina;

import br.recife.edu.ifpe.model.classes.Grupo;
import br.recife.edu.ifpe.model.classes.Vacina;
import br.recife.edu.ifpe.model.repositorios.RepositorioGrupo;
import br.recife.edu.ifpe.model.repositorios.RepositorioVacina;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author pedro
 */
@WebServlet(name = "VacinaServlet", urlPatterns = {"/VacinaServlet"})
public class VacinaServlet extends HttpServlet {

protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        
          int id = Integer.parseInt(request.getParameter("id"));
           
          Vacina v =  RepositorioVacina.getCurrentInstance().read(id);
          
          request.setAttribute("vacina", v);
          
          getServletContext().getRequestDispatcher("/Vacinas.jsp").forward(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
          int id = Integer.parseInt(request.getParameter("id"));
          String nome = request.getParameter("nome");
          String fabricante = request.getParameter("fabricante");
          String tempoEntreAplicacoes = request.getParameter("tempoEntreAplicacoes");
          int quantidadeAplicacoes = Integer.parseInt(request.getParameter("quantidadeAplicacoes"));
          String a = request.getParameter("atualizar");
          Vacina v= new Vacina();
          
          v.setId(id);
          v.setNome(nome);
          v.setFabricante(fabricante);
          v.setTempoEntreAplicacoes(tempoEntreAplicacoes);
          v.setQuantidadeAplicacoes(quantidadeAplicacoes);
          HttpSession session = request.getSession(true);
          
          if(a == null){
        RepositorioVacina.getCurrentInstance().insert(v);
          //ItemEstoque item = new ItemEstoque();
 
          //item.setQuantidade(0);
          //item.setCodigo(g.getId());
          
         // RepositorioGrupo.getCurrentInstance().read().addItem(item);
         
          session.setAttribute("msg","Vacina" +v.getNome()+ "foi cadastrada com sucesso");    
          
          }else{
              
          RepositorioVacina.getCurrentInstance().update(v);
          session.setAttribute("msg","Vacina" +v.getNome()+ "foi atualizada com sucesso");    
          }
          
          response.sendRedirect("Vacinas.jsp");
    }

  
 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
   
    
    protected  void doDelete(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException{
        super.doDelete(request, response);
        
        int id = Integer.parseInt(request.getParameter("id"));
        Vacina v = RepositorioVacina.getCurrentInstance().read(id);
        RepositorioVacina.getCurrentInstance().delete(v);
        
        HttpSession session = request.getSession();
        
        session.setAttribute("msg", "O vacina"+v.getNome()+"foi deletada");
    }

}
