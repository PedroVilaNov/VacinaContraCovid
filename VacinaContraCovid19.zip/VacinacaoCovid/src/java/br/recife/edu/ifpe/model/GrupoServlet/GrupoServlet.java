/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.recife.edu.ifpe.model.GrupoServlet;

import br.recife.edu.ifpe.model.classes.Grupo;
import br.recife.edu.ifpe.model.repositorios.RepositorioGrupo;
import br.recife.edu.ifpe.model.repositorios.RepositorioPaciente;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author pedro
 */
@WebServlet(name = "GrupoServlet", urlPatterns = {"/GrupoServlet"})
public class GrupoServlet extends HttpServlet {

 protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        
          int id = Integer.parseInt(request.getParameter("id"));
           
          Grupo g =  RepositorioGrupo.getCurrentInstance().read(id);
          
          request.setAttribute("grupo", g);
          
          getServletContext().getRequestDispatcher("/Grupos.jsp").forward(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
          int id = Integer.parseInt(request.getParameter("id"));
          String denominacao = request.getParameter("denominacao");
          int idadeMinima = Integer.parseInt(request.getParameter("idadeMinima"));
          int idadeMaxima = Integer.parseInt(request.getParameter("idadeMaxima"));
          String a = request.getParameter("atualizar");
          Grupo g= new Grupo();
          
          g.setId(id);
          g.setDenominacao(denominacao);
          g.setIdadeMinima(idadeMinima);
          g.setIdadeMaxima(idadeMaxima);
          
          HttpSession session = request.getSession(true);
          
          if(a == null){
          RepositorioGrupo.getCurrentInstance().insert(g);
          //ItemEstoque item = new ItemEstoque();
 
          //item.setQuantidade(0);
          //item.setCodigo(g.getId());
          
         // RepositorioGrupo.getCurrentInstance().read().addItem(item);
         
          session.setAttribute("msg","Grupo" +g.getDenominacao()+ "foi cadastro com sucesso");    
          
          }else{
              
          RepositorioGrupo.getCurrentInstance().update(g);
          session.setAttribute("msg","Grupo" +g.getDenominacao()+ "foi atualizado com sucesso");    
          }
          
          response.sendRedirect("Grupos.jsp");
    }

  
 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
   
    
    protected  void doDelete(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException{
        super.doDelete(request, response);
        
        int id = Integer.parseInt(request.getParameter("id"));
        Grupo g = RepositorioGrupo.getCurrentInstance().read(id);
        RepositorioGrupo.getCurrentInstance().delete(g);
        
        HttpSession session = request.getSession();
        
        session.setAttribute("msg", "O grupo"+g.getDenominacao()+"foi deletado");
    }

}
