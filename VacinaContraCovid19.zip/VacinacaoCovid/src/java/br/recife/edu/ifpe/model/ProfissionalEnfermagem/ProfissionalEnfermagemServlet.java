/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.recife.edu.ifpe.model.ProfissionalEnfermagem;

import br.recife.edu.ifpe.model.classes.Grupo;
import br.recife.edu.ifpe.model.classes.ProfissionalEnfermagem;
import br.recife.edu.ifpe.model.repositorios.RepositorioGrupo;
import br.recife.edu.ifpe.model.repositorios.RepositorioProfissionalEnfermagem;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author pedro
 */
@WebServlet(name = "ProfissionalEnfermagemServlet", urlPatterns = {"/ProfissionalEnfermagemServlet"})
public class ProfissionalEnfermagemServlet extends HttpServlet {

 protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        
          int id = Integer.parseInt(request.getParameter("id"));
           
          ProfissionalEnfermagem p =  RepositorioProfissionalEnfermagem.getCurrentInstance().read(id);
          
          request.setAttribute("profissional", p);
          
          getServletContext().getRequestDispatcher("/Profissionais.jsp").forward(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
          int id = Integer.parseInt(request.getParameter("id"));
          String nome = request.getParameter("nome");
          String coren = request.getParameter("coren");
          int anoFormacao = Integer.parseInt(request.getParameter("anoFormacao"));
                 String contato = request.getParameter("contato");
          String a = request.getParameter("atualizar");
          ProfissionalEnfermagem p = new ProfissionalEnfermagem();
          
          p.setId(id);
          p.setNome(nome);
          p.setCoren(coren);
          p.setAnoFormacao(anoFormacao);
          p.setContato(contato);
          HttpSession session = request.getSession(true);
          
          if(a == null){
          RepositorioProfissionalEnfermagem.getCurrentInstance().insert(p);
          //ItemEstoque item = new ItemEstoque();
 
          //item.setQuantidade(0);
          //item.setCodigo(g.getId());
          
         // RepositorioGrupo.getCurrentInstance().read().addItem(item);
         
          session.setAttribute("msg","Profissional" +p.getNome()+ "foi cadastro com sucesso");    
          
          }else{
              
          RepositorioProfissionalEnfermagem.getCurrentInstance().update(p);
          session.setAttribute("msg","Profissional" +p.getNome()+ "foi atualizado com sucesso");    
          }
          
          response.sendRedirect("Profissionais.jsp");
    }

  
 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
   
    
    protected  void doDelete(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException{
        super.doDelete(request, response);
        
        int id = Integer.parseInt(request.getParameter("id"));
         ProfissionalEnfermagem p =  RepositorioProfissionalEnfermagem.getCurrentInstance().read(id);
         RepositorioProfissionalEnfermagem.getCurrentInstance().delete(p);
        
        HttpSession session = request.getSession();
        
        session.setAttribute("msg", "O profissional"+p.getNome()+"foi deletado");
    }

}
