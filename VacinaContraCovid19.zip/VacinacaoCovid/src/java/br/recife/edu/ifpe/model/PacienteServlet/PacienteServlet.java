package br.recife.edu.ifpe.model.PacienteServlet;

import br.recife.edu.ifpe.model.classes.Aplicacao;
import br.recife.edu.ifpe.model.classes.Grupo;
import br.recife.edu.ifpe.model.classes.Paciente;
import br.recife.edu.ifpe.model.classes.ProfissionalEnfermagem;
import br.recife.edu.ifpe.model.classes.Vacina;
import br.recife.edu.ifpe.model.repositorios.RepositorioGrupo;
import br.recife.edu.ifpe.model.repositorios.RepositorioPaciente;
import br.recife.edu.ifpe.model.repositorios.RepositorioProfissionalEnfermagem;
import br.recife.edu.ifpe.model.repositorios.RepositorioVacina;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author pedro
 */
@WebServlet(name = "PacienteServlet", urlPatterns = {"/PacienteServlet"})
public class PacienteServlet extends HttpServlet {

 protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
        
          int id = Integer.parseInt(request.getParameter("id"));
           
          Paciente p =  RepositorioPaciente.getCurrentInstance().read(id);
          
          request.setAttribute("paciente", p);
          
          
          
          getServletContext().getRequestDispatcher("/Pacientes.jsp").forward(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
          int id = Integer.parseInt(request.getParameter("id"));
          int idap  = 0;
         if(request.getParameter("idap") != null){
         idap = Integer.parseInt(request.getParameter("idap"));       
         } 
     
         
          String nome = request.getParameter("nome");
          String CaracteristicasIndividuais = request.getParameter("CaracteristicasIndividuais");
          
         String descricao = request.getParameter("descricao");

         int hora = 0;
         if(request.getParameter("hora") != null){
          hora  = Integer.parseInt(request.getParameter("hora"));   
         } 
          String a = request.getParameter("atualizar");
        int codigog  = Integer.parseInt(request.getParameter("codigog"));       
         
            int codigov =  0;
             if(request.getParameter("codigov") != null){
           codigov   = Integer.parseInt(request.getParameter("codigov"));       
         } 
               int codigope =  0;
                  if(request.getParameter("codigope") != null){
           codigope  = Integer.parseInt(request.getParameter("codigope")); // id de aplicação        
         } 
          Paciente p = new Paciente();
          
          Aplicacao ap = new Aplicacao();
         ProfissionalEnfermagem pe = RepositorioProfissionalEnfermagem.getCurrentInstance().read(codigope);
         Vacina v = RepositorioVacina.getCurrentInstance().read(codigov);
          
        
     
         Date dataNascimento = new Date();
      
     try {  
         dataNascimento=new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("dataNascimento"));
     } catch (ParseException ex) {
         Logger.getLogger(PacienteServlet.class.getName()).log(Level.SEVERE, null, ex);
     }
     
        Date dataAp = new Date();
      try {  
          
             if(request.getParameter("codigope") != null){
           dataAp =new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("dataAp"));     
         } 
     } catch (ParseException ex) {
         Logger.getLogger(PacienteServlet.class.getName()).log(Level.SEVERE, null, ex);
     }

          Grupo g = RepositorioGrupo.getCurrentInstance().read( codigog);
          p.setId(id);
          p.setNome(nome);
          p.setDataNascimento(dataNascimento);
          p.setCaracteristicasIndividuais(CaracteristicasIndividuais);
          p.setGrupo(g);
          HttpSession session = request.getSession(true);
    
          ap.setAplicador(pe);
          ap.setVacina(v);
          ap.setDescricao(descricao);
          ap.setId(idap);
          ap.setHora(hora);
          ap.setData(dataAp);
        
         
          if(a == null){
              p.getAplicacoes().add(ap);
          RepositorioPaciente.getCurrentInstance().insert(p);
      
         
          session.setAttribute("msg","Paciente" +p.getNome()+ "foi cadastro com sucesso");    
          
          }else{
              
          RepositorioPaciente.getCurrentInstance().update(p);
          session.setAttribute("msg","Paciente" +p.getNome()+ "foi atualizado com sucesso");    
          }
           
          response.sendRedirect("Pacientes.jsp");
          
    }

  
 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
   
    
    protected  void doDelete(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException{
        super.doDelete(request, response);
        
        int id = Integer.parseInt(request.getParameter("id"));
        Paciente p = RepositorioPaciente.getCurrentInstance().read(id);
        RepositorioPaciente.getCurrentInstance().delete(p);
        
        HttpSession session = request.getSession();
        
        session.setAttribute("msg", "O paciente"+p.getNome()+"foi deletado");
    }

}
